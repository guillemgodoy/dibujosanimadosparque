g++ -Wall ejecutarcomandos.cc -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -o ejecutarcomandos
